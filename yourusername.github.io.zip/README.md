# Minecraft Eaglercraft

This repository is a GitHub Pages hosted online version of Minecraft using Eaglercraft.

## How to deploy
1. Go to settings → Pages
2. Deploy from the main branch
3. Your game will be live at:
   https://yourusername.github.io/
