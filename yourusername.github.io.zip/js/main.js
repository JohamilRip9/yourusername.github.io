window.onload = function() {
    console.log("Minecraft Eaglercraft loaded");
    document.getElementById("game-container").innerHTML =
        "<h1>Welcome to Minecraft Eaglercraft!</h1>";
};