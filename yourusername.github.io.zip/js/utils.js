// Placeholder utilities
function log(msg) { console.log("[Eaglercraft]", msg); }